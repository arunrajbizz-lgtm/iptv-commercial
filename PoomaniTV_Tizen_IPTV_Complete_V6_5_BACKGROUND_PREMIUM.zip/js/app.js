/* V6.2 hotfix: make DOM selector available before any async/list code runs */
window.$ = window.$ || function(id){ return document.getElementById(id); };
var $ = window.$;

var API_CACHE={};
var API_CACHE_TTL=5*60*1000;
var KEY_THROTTLE_MS=90;
var LAST_KEY_TIME=0;
var LAST_KEY_CODE="";
var MAX_INITIAL_ITEMS=180;
var CONTINUE_KEY="poomani_continue_v1";

function nowMs(){return (typeof performance!=="undefined"&&performance.now)?performance.now():Date.now();}
function cacheKey(action,params){return server+"|"+username+"|"+action+"|"+(params||"");}
function getCached(action,params){
  var k=cacheKey(action,params), c=API_CACHE[k];
  if(c && Date.now()-c.t<API_CACHE_TTL)return c.v;
  return null;
}
function setCached(action,params,val){API_CACHE[cacheKey(action,params)]={t:Date.now(),v:val};}
function clearApiCache(){API_CACHE={};}
function shouldThrottleKey(e){
  var code=e.keyCode||e.which||e.code||e.key||"";
  var t=nowMs();
  if(code===LAST_KEY_CODE && t-LAST_KEY_TIME<KEY_THROTTLE_MS)return true;
  LAST_KEY_CODE=code; LAST_KEY_TIME=t; return false;
}
function safeImg(src,cls){
  if(!src)return "";
  return "<img class=\""+(cls||"logo")+"\" loading=\"lazy\" src=\""+esc(src)+"\" onerror=\"this.style.display='none'\">";
}
function saveContinue(type,item,url,pos,dur){
  try{
    var arr=JSON.parse(localStorage.getItem(CONTINUE_KEY)||"[]");
    var id=(item&&(item.stream_id||item.id||item.episode_id||item.name||item.title))||url;
    arr=arr.filter(function(x){return !(x.type===type && x.id===id)});
    arr.unshift({type:type,id:id,title:(item&&(item.name||item.title))||currentSourceTitle||"Playing",url:url||currentUrl||"",pos:pos||0,dur:dur||0,ts:Date.now()});
    arr=arr.slice(0,50);
    localStorage.setItem(CONTINUE_KEY,JSON.stringify(arr));
  }catch(e){}
}
function getContinueList(){try{return JSON.parse(localStorage.getItem(CONTINUE_KEY)||"[]")}catch(e){return []}}
function renderListChunked(containerId,items,renderer,limit){
  var el=document.getElementById(containerId); if(!el)return;
  items=items||[]; limit=limit||MAX_INITIAL_ITEMS;
  var shown=items.slice(0,limit);
  el.innerHTML=shown.map(renderer).join("");
  if(items.length>limit){
    el.innerHTML+='<div class="item focusable" data-action="loadMore" data-list="'+esc(containerId)+'">Load more ('+(items.length-limit)+')</div>';
  }
}
function loadMoreList(containerId){
  if(containerId==="channelList" && currentChannels) renderList(containerId,currentChannels,channelRenderer);
  else if(containerId==="movieList" && currentMovies) renderList(containerId,currentMovies,movieRenderer);
  else if(containerId==="seriesList" && currentEpisodes) renderList(containerId,currentEpisodes,episodeRenderer);
  focusFirst();
}
function buildMasterSearchIndex(){
  var out=[];
  try{(liveChannels||[]).forEach(function(x){out.push({type:"live",name:x.name||"",item:x})})}catch(e){}
  try{(vodStreams||currentMovies||[]).forEach(function(x){out.push({type:"movie",name:x.name||"",item:x})})}catch(e){}
  try{(seriesStreams||currentSeries||[]).forEach(function(x){out.push({type:"series",name:x.name||"",item:x})})}catch(e){}
  window.__masterSearchIndex=out;
  return out;
}
function masterSearch(q){
  q=String(q||"").toLowerCase().trim();
  if(!q)return [];
  var idx=window.__masterSearchIndex||buildMasterSearchIndex();
  return idx.filter(function(x){return String(x.name||"").toLowerCase().indexOf(q)>=0}).slice(0,100);
}

/* PoomaniTV V5.0 Professional Rebuild - Samsung Tizen IPTV */
(function(){
"use strict";

/* ---------- State ---------- */
var server="", username="", password="", playlistType="xtream";
var playlists=[], activePlaylistIndex=-1;
var currentPage="loginPage", lastSectionPage="homePage";
var focusIndex=0, navZone="categories";
var liveLoaded=false, moviesLoaded=false, seriesLoaded=false, catchupLoaded=false;
var liveCategories=[], liveChannelsAll=[], currentChannels=[];
var movieCategories=[], moviesAll=[], currentMovies=[];
var seriesCategories=[], seriesAll=[], currentSeries=[];
var catchupChannels=[], catchupEpg=[], catchupDates=[], currentCatchupChannel=null, currentCatchupPrograms=[];
var currentEpisodes=[];
var currentPlayList=[], currentPlayIndex=0, currentPlayType="";
var fitMode="contain", defaultFitMode="contain";
var useAVPlay=false, avplayPrepared=false, avplayPlaying=false, avplayTracks=[];
var currentSourceCandidates=[], currentSourceCandidateIndex=0, currentSourceTitle="", retryingSource=false;
var currentCandidateList=[], currentCandidateIndex=0, currentUrl="";
var trackMode="audio", availableAudioTracks=[], availableSubtitleTracks=[];
var lastVodInfoCache={}, lastSeriesInfoCache={}, currentMovieInfo=null, currentEpisodeInfo=null;

/* ---------- Utilities ---------- */
function $(id){return document.getElementById(id)}
function qs(sel,root){return Array.prototype.slice.call((root||document).querySelectorAll(sel))}
function toast(msg,ms){var t=$("toast"); if(!t)return; t.textContent=msg; t.classList.remove("hidden"); clearTimeout(t._tm); t._tm=setTimeout(function(){t.classList.add("hidden")},ms||2600)}
function showLoader(v){var l=$("loader"); if(l)l.classList.toggle("hidden",!v)}
function esc(s){return String(s==null?"":s).replace(/[&<>"']/g,function(c){return {"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]})}
function safeLogo(src){src=String(src||"").trim(); if(!src)return "img/default-logo.png"; if(src.indexOf("//")===0)return "https:"+src; return src}
function imgTag(src,cls){return '<img '+(cls?'class="'+esc(cls)+'" ':'')+'src="'+esc(safeLogo(src))+'" onerror="this.onerror=null;this.src=\'img/default-logo.png\';">'}
function unique(arr){var s={},o=[]; (arr||[]).forEach(function(x){if(x&&!s[x]){s[x]=1;o.push(x)}}); return o}
function isM3U(){return playlistType==="m3u"}
function api(action,extra){
  var url=server.replace(/\/$/,"")+"/player_api.php?username="+encodeURIComponent(username)+"&password="+encodeURIComponent(password);
  if(action)url+="&action="+encodeURIComponent(action);
  if(extra)url+="&"+extra;
  return fetch(url).then(function(r){if(!r.ok)throw new Error("HTTP "+r.status); return r.json()})
}
function renderList(id,arr,mapper){var el=$(id); if(el)el.innerHTML=(arr||[]).map(mapper).join("")}
function resetContentCache(){liveLoaded=moviesLoaded=seriesLoaded=catchupLoaded=false; liveCategories=[]; liveChannelsAll=[]; currentChannels=[]; movieCategories=[]; moviesAll=[]; currentMovies=[]; seriesCategories=[]; seriesAll=[]; currentSeries=[]; catchupChannels=[]}

/* ---------- Focus / Remote Navigation ---------- */
function searchOpen(){return $("searchModal") && !$("searchModal").classList.contains("hidden")}
function trackOpen(){return $("trackModal") && !$("trackModal").classList.contains("hidden")}
function activeRoot(){if(trackOpen())return $("trackModal"); if(searchOpen())return $("searchModal"); return $(currentPage)||document}
function focusables(){return qs(".focusable:not([disabled])",activeRoot()).filter(function(e){return e.offsetParent!==null})}
function clearFocus(){qs(".focus").forEach(function(e){e.classList.remove("focus")}); try{document.activeElement.blur()}catch(e){}}
function applyFocus(){clearFocus(); var f=focusables(); if(!f.length)return; if(focusIndex<0)focusIndex=0; if(focusIndex>=f.length)focusIndex=f.length-1; var el=f[focusIndex]; el.classList.add("focus"); if(el.tagName==="INPUT"||el.tagName==="SELECT"){try{el.focus()}catch(e){}}else{try{document.activeElement.blur()}catch(e){}} try{el.scrollIntoView({block:"nearest",inline:"nearest"})}catch(e){}}
function focusFirst(){focusIndex=0; applyFocus()}
function setFocusEl(el){var f=focusables(); var i=f.indexOf(el); if(i>=0){focusIndex=i; applyFocus()}}
function pressEffect(el){if(!el)return; el.classList.add("pressed"); setTimeout(function(){el.classList.remove("pressed")},180)}
function updateSplitMode(){["livePage","moviesPage","seriesPage","catchupPage"].forEach(function(p){var sp=$(p)&&$(p).querySelector(".split"); if(sp){sp.classList.toggle("channels-mode",navZone==="channels"); sp.classList.toggle("categories-mode",navZone!=="channels")}})}
function zoneItems(zone){
  var sel=".focusable";
  if(currentPage==="livePage")sel=zone==="channels"?"#liveChannels .focusable":"#liveCategories .focusable,.topbar .focusable";
  if(currentPage==="moviesPage")sel=zone==="channels"?"#movieList .focusable":"#movieCategories .focusable,.topbar .focusable";
  if(currentPage==="seriesPage")sel=zone==="channels"?"#seriesList .focusable":"#seriesCategories .focusable,.topbar .focusable";
  if(currentPage==="catchupPage")sel=zone==="channels"?"#catchupDates .focusable,#catchupPrograms .focusable":"#catchupChannels .focusable,.topbar .focusable";
  return qs(sel,$(currentPage)).filter(function(e){return e.offsetParent!==null})
}
function movePlayerControls(dir){
  var arr=qs("#playerControls .focusable").filter(function(e){return e.offsetParent!==null});
  if(!arr.length)return true;
  if(dir==="up"||dir==="down")return true;
  var cur=focusables()[focusIndex], idx=arr.indexOf(cur);
  if(idx<0)idx=(dir==="left"?arr.length-1:0); else idx += (dir==="right"?1:-1);
  if(idx<0)idx=0; if(idx>=arr.length)idx=arr.length-1; setFocusEl(arr[idx]); return true;
}
function moveDir(dir){
  if(currentPage==="playerPage"&&!searchOpen()&&!trackOpen()){movePlayerControls(dir);return}
  if(["livePage","moviesPage","seriesPage","catchupPage"].indexOf(currentPage)>=0&&!searchOpen()&&!trackOpen()){
    if(dir==="right"&&navZone==="categories"){var ch=zoneItems("channels"); if(ch.length){navZone="channels"; updateSplitMode(); setFocusEl(ch[0]); return}}
    if(dir==="left"&&navZone==="channels"){var ca=zoneItems("categories"); navZone="categories"; updateSplitMode(); if(ca.length)setFocusEl(ca[Math.min(2,ca.length-1)]); return}
    if(dir==="up"||dir==="down"){var arr=zoneItems(navZone), cur=focusables()[focusIndex], idx=arr.indexOf(cur); if(arr.length){if(idx<0)idx=0; idx+=(dir==="down"?1:-1); if(idx<0)idx=0; if(idx>=arr.length)idx=arr.length-1; setFocusEl(arr[idx]); return}}
  }
  var f=focusables(); if(!f.length)return; var cols=(currentPage==="homePage"?3:(searchOpen()?5:1)); var n=focusIndex;
  if(dir==="left")n--; if(dir==="right")n++; if(dir==="up")n-=cols; if(dir==="down")n+=cols;
  if(n<0)n=0; if(n>=f.length)n=f.length-1; focusIndex=n; applyFocus();
}
function selectFocused(){var f=focusables()[focusIndex]; if(!f)return; if(f.tagName==="INPUT"||f.tagName==="SELECT"){f.focus();return} pressEffect(f); handleAction(f)}

/* ---------- Pages / Login / Playlists ---------- */
function showPage(id){qs(".page").forEach(function(p){p.classList.remove("active")}); var p=$(id); if(!p)return; p.classList.add("active"); currentPage=id; navZone="categories"; updateSplitMode(); if(id==="settingsPage")renderPlaylists(); setTimeout(function(){id==="playerPage"?clearFocus():focusFirst()},80)}
function loadPlaylistStore(){try{playlists=JSON.parse(localStorage.getItem("iptvPlaylists")||"[]"); activePlaylistIndex=parseInt(localStorage.getItem("activePlaylistIndex")||"-1",10)}catch(e){playlists=[];activePlaylistIndex=-1} defaultFitMode=localStorage.getItem("defaultFitMode")||"contain"; fitMode=defaultFitMode}
function savePlaylistStore(){localStorage.setItem("iptvPlaylists",JSON.stringify(playlists)); localStorage.setItem("activePlaylistIndex",String(activePlaylistIndex))}
function applyAccount(p){p=p||{}; playlistType=p.type||"xtream"; server=p.server||""; username=p.username||""; password=p.password||""}
function login(){server=($("serverInput").value||"").trim(); username=($("usernameInput").value||"").trim(); password=($("passwordInput").value||"").trim(); playlistType="xtream"; if(!server||!username||!password){toast("Enter server, username and password");return} var p={type:"xtream",name:"Default",server:server,username:username,password:password}; localStorage.setItem("iptvLogin",JSON.stringify(p)); var found=-1; playlists.forEach(function(x,i){if(x.server===server&&x.username===username)found=i}); if(found>=0){playlists[found]=p;activePlaylistIndex=found}else{playlists.push(p);activePlaylistIndex=playlists.length-1} savePlaylistStore(); resetContentCache(); showPage("homePage")}
function resetAppData(){localStorage.clear(); toast("Saved data cleared"); setTimeout(function(){location.reload()},700)}
function logout(){localStorage.removeItem("iptvLogin"); location.reload()}
function clearCache(){resetContentCache(); toast("Content cache cleared")}
function savePlaylist(){var type=$("plTypeInput")?$("plTypeInput").value:"xtream"; var p={type:type,name:($("plNameInput").value||"").trim()||"IPTV Account",server:($("plServerInput").value||"").trim(),username:($("plUserInput").value||"").trim(),password:($("plPassInput").value||"").trim()}; if(!p.server){toast("Enter URL");return} if(type==="xtream"&&(!p.username||!p.password)){toast("Enter Xtream username/password");return} playlists.push(p); activePlaylistIndex=playlists.length-1; savePlaylistStore(); activatePlaylist(activePlaylistIndex)}
function activatePlaylist(i){i=parseInt(i,10); if(i<0||i>=playlists.length)return; activePlaylistIndex=i; applyAccount(playlists[i]); localStorage.setItem("iptvLogin",JSON.stringify(playlists[i])); savePlaylistStore(); resetContentCache(); renderPlaylists(); toast("Activated "+playlists[i].name)}
function deletePlaylist(i){i=parseInt(i,10); if(i<0||i>=playlists.length)return; playlists.splice(i,1); if(activePlaylistIndex>=playlists.length)activePlaylistIndex=playlists.length-1; savePlaylistStore(); renderPlaylists()}
function renderPlaylists(){if(!$("playlistList"))return; if($("plServerInput"))$("plServerInput").value=server; if($("plUserInput"))$("plUserInput").value=username; if($("plPassInput"))$("plPassInput").value=password; if($("plTypeInput"))$("plTypeInput").value=playlistType; if($("defaultFitBtn"))$("defaultFitBtn").textContent=defaultFitMode==="cover"?"Fill Screen":"Fit Screen"; $("playlistList").innerHTML=playlists.map(function(p,i){return '<div class="playlist-item"><span>'+(i===activePlaylistIndex?"✓ ":"")+"["+esc((p.type||"xtream").toUpperCase())+"] "+esc(p.name)+'<br><small>'+esc(p.server)+'</small></span><button class="focusable small-btn" data-action="activatePlaylist" data-index="'+i+'">Activate</button><button class="focusable small-btn" data-action="deletePlaylist" data-index="'+i+'">Delete</button></div>'}).join("")}
function toggleDefaultFit(){defaultFitMode=defaultFitMode==="contain"?"cover":"contain"; localStorage.setItem("defaultFitMode",defaultFitMode); fitMode=defaultFitMode; try{$("videoPlayer").style.objectFit=fitMode}catch(e){} renderPlaylists(); toast(defaultFitMode==="cover"?"Default: Fill Screen":"Default: Fit Screen")}

/* ---------- Content Loading ---------- */
async function loadM3U(){var text=await fetch(server).then(function(r){return r.text()}); var lines=text.split(/\r?\n/), items=[], cats={}; for(var i=0;i<lines.length;i++){if(lines[i].indexOf("#EXTINF")===0){var name=(lines[i].split(",").pop()||"Channel").trim(); var logo=(lines[i].match(/tvg-logo="([^"]*)"/)||[])[1]||""; var group=(lines[i].match(/group-title="([^"]*)"/)||[])[1]||"M3U"; var url=(lines[i+1]||"").trim(); if(url&&url.charAt(0)!=="#"){items.push({name:name,stream_icon:logo,category_name:group,url:url,stream_id:i}); cats[group]=1}}} liveChannelsAll=items; liveCategories=Object.keys(cats).map(function(g){return {category_id:g,category_name:g}})}
async function openLive(){lastSectionPage="livePage"; showPage("livePage"); if(liveLoaded)return; showLoader(true); try{if(isM3U())await loadM3U(); else{liveCategories=await api("get_live_categories"); liveChannelsAll=await api("get_live_streams")} renderList("liveCategories",liveCategories,function(c){return '<div class="item focusable" data-cat-live="'+esc(c.category_id)+'">'+esc(c.category_name)+'</div>'}); liveLoaded=true}catch(e){toast("Live loading failed: "+e.message)} showLoader(false); focusFirst()}
function loadLiveChannels(cat){currentChannels=liveChannelsAll.filter(function(x){return isM3U()?String(x.category_name)===String(cat):String(x.category_id)===String(cat)}); renderList("liveChannels",currentChannels,function(ch,i){return '<div class="channel focusable" data-live-index="'+i+'">'+imgTag(ch.stream_icon)+'<span>'+esc(ch.name)+'</span></div>'}); navZone="categories"; updateSplitMode(); focusFirst()}
async function openMovies(){lastSectionPage="moviesPage"; showPage("moviesPage"); if(isM3U()){toast("Movies require Xtream account");return} if(moviesLoaded)return; showLoader(true); try{movieCategories=await api("get_vod_categories"); moviesAll=await api("get_vod_streams"); renderList("movieCategories",movieCategories,function(c){return '<div class="item focusable" data-cat-movie="'+esc(c.category_id)+'">'+esc(c.category_name)+'</div>'}); moviesLoaded=true}catch(e){toast("Movies loading failed: "+e.message)} showLoader(false); focusFirst()}
function loadMovies(cat){currentMovies=moviesAll.filter(function(x){return String(x.category_id)===String(cat)}); renderListChunked("movieList",currentMovies,function(m,i){return '<div class="poster focusable" data-movie-index="'+i+'">'+imgTag(m.stream_icon)+'<div>'+esc(m.name)+'</div></div>'}); navZone="categories"; updateSplitMode(); focusFirst()}
async function openSeries(){lastSectionPage="seriesPage"; showPage("seriesPage"); if(isM3U()){toast("Series require Xtream account");return} if(seriesLoaded)return; showLoader(true); try{seriesCategories=await api("get_series_categories"); seriesAll=await api("get_series"); renderList("seriesCategories",seriesCategories,function(c){return '<div class="item focusable" data-cat-series="'+esc(c.category_id)+'">'+esc(c.category_name)+'</div>'}); seriesLoaded=true}catch(e){toast("Series loading failed: "+e.message)} showLoader(false); focusFirst()}
function loadSeries(cat){if($("seriesRightTitle"))$("seriesRightTitle").textContent="Series"; currentSeries=seriesAll.filter(function(x){return String(x.category_id)===String(cat)}); renderList("seriesList",currentSeries,function(s,i){return '<div class="poster focusable" data-series-index="'+i+'">'+imgTag(s.cover)+'<div>'+esc(s.name)+'</div></div>'}); navZone="categories"; updateSplitMode(); focusFirst()}
async function openSeriesInfo(i){
  var s=currentSeries[i]; if(!s)return;
  showLoader(true);
  try{
    var info=await api("get_series_info","series_id="+encodeURIComponent(s.series_id));
    var eps=[];
    Object.keys(info.episodes||{}).forEach(function(season){
      (info.episodes[season]||[]).forEach(function(e){
        e._series_name=s.name; e._season=season; eps.push(e);
      });
    });
    currentEpisodes=eps;
    if($("seriesRightTitle"))$("seriesRightTitle").textContent=s.name+" Episodes";
    renderListChunked("seriesList",currentEpisodes,function(e,idx){
      var ext=e.container_extension||e.containerExtension||"mp4";
      var eid=e.id||e.episode_id||e.stream_id;
      var url=e.url || e.direct_source || (server.replace(/\/$/,"")+"/series/"+username+"/"+password+"/"+eid+"."+ext);
      var title=e.title||e.name||("Episode "+(idx+1));
      return '<div class="item focusable" data-episode-index="'+idx+'" data-episode-url="'+esc(url)+'" data-title="'+esc(title)+'">S'+esc(e.season||e._season||"")+' E'+esc(e.episode_num||e.episode||"")+' - '+esc(title)+'</div>';
    });
  }catch(e){toast("Episodes failed: "+e.message)}
  showLoader(false); navZone="channels"; updateSplitMode(); focusFirst();
}

/* ---------- Catchup EPG ---------- */
function b64decodeSafe(s){if(!s)return ""; try{return decodeURIComponent(escape(atob(s)))}catch(e){try{return atob(s)}catch(x){return s}}}
function pad2(n){return n<10?"0"+n:""+n}
function parseEpgTime(v){if(!v)return null; if(typeof v==="number")return new Date(v*1000); var s=String(v); if(/^\d+$/.test(s))return new Date(parseInt(s,10)*1000); var d=new Date(s.replace(" ","T")); return isNaN(d.getTime())?null:d}
function fmtDateKey(d){return d.getFullYear()+"-"+pad2(d.getMonth()+1)+"-"+pad2(d.getDate())}
function fmtDateLabel(k){var p=k.split("-"); return p[2]+"/"+p[1]}
function fmtTime(d){return pad2(d.getHours())+":"+pad2(d.getMinutes())}
function timeshiftStart(d){return d.getFullYear()+"-"+pad2(d.getMonth()+1)+"-"+pad2(d.getDate())+":"+pad2(d.getHours())+"-"+pad2(d.getMinutes())}
function minsBetween(a,b){if(!a||!b)return 60; var m=Math.round((b-a)/60000); return m<1?60:m}
async function openCatchup(){lastSectionPage="catchupPage"; showPage("catchupPage"); if(isM3U()){toast("Catchup requires Xtream account");return} if(catchupLoaded)return; showLoader(true); try{if(!liveChannelsAll.length)liveChannelsAll=await api("get_live_streams"); catchupChannels=liveChannelsAll.filter(function(ch){return ch.tv_archive==1||ch.tv_archive==="1"||parseInt(ch.tv_archive_duration||"0",10)>0}); renderList("catchupChannels",catchupChannels,function(ch,i){return '<div class="item focusable" data-catchup-channel="'+i+'">'+esc(ch.name)+(ch.tv_archive_duration?' <small>('+esc(ch.tv_archive_duration)+' days)</small>':'')+'</div>'}); if($("catchupTitle"))$("catchupTitle").textContent=catchupChannels.length?"Select channel to load available EPG":"No catchup channels found"; catchupLoaded=true}catch(e){toast("Catchup loading failed: "+e.message)} showLoader(false); focusFirst()}
async function loadCatchupEpg(index){currentCatchupChannel=catchupChannels[index]; if(!currentCatchupChannel)return; if($("catchupTitle"))$("catchupTitle").textContent=currentCatchupChannel.name+" - Loading EPG..."; if($("catchupDates"))$("catchupDates").innerHTML=""; if($("catchupPrograms"))$("catchupPrograms").innerHTML=""; showLoader(true); try{var data=await api("get_simple_data_table","stream_id="+encodeURIComponent(currentCatchupChannel.stream_id)); var list=data.epg_listings||data.epg||data.listings||[]; catchupEpg=list.map(function(x){var start=parseEpgTime(x.start_timestamp||x.start), end=parseEpgTime(x.stop_timestamp||x.end||x.stop); return {start:start,end:end,title:b64decodeSafe(x.title||x.name||"Program"),desc:b64decodeSafe(x.description||x.desc||"")}}).filter(function(x){return x.start}).sort(function(a,b){return a.start-b.start}); var seen={}; catchupDates=[]; catchupEpg.forEach(function(p){var k=fmtDateKey(p.start); if(!seen[k]){seen[k]=1; catchupDates.push(k)}}); renderCatchupDates(); if(catchupDates.length)loadCatchupDate(catchupDates[catchupDates.length-1]); else if($("catchupPrograms"))$("catchupPrograms").innerHTML='<div class="empty">No EPG available.</div>'}catch(e){toast("EPG loading failed: "+e.message)} showLoader(false)}
function renderCatchupDates(){if($("catchupDates"))$("catchupDates").innerHTML=catchupDates.map(function(d){return '<div class="date-pill focusable" data-catchup-date="'+esc(d)+'">'+esc(fmtDateLabel(d))+'</div>'}).join("")}
function loadCatchupDate(dateKey){currentCatchupPrograms=catchupEpg.filter(function(p){return fmtDateKey(p.start)===dateKey}); if($("catchupPrograms"))$("catchupPrograms").innerHTML=currentCatchupPrograms.map(function(p,i){var dur=minsBetween(p.start,p.end); return '<div class="program-item focusable" data-catchup-program="'+i+'"><div class="program-time">'+esc(fmtTime(p.start))+' - '+esc(p.end?fmtTime(p.end):"")+'</div><div><div class="program-title">'+esc(p.title)+'</div><div class="program-desc">'+esc(p.desc)+'</div></div><div class="program-duration">'+dur+' min</div></div>'}).join(""); navZone="channels"; updateSplitMode(); setTimeout(function(){var pr=document.querySelector("#catchupPrograms .focusable"); if(pr)setFocusEl(pr)},60)}
function playCatchupProgram(i){var p=currentCatchupPrograms[i]; if(!p||!currentCatchupChannel)return; var dur=minsBetween(p.start,p.end), start=timeshiftStart(p.start); var url=server.replace(/\/$/,"")+"/timeshift/"+username+"/"+password+"/"+dur+"/"+start+"/"+currentCatchupChannel.stream_id+".ts"; currentPlayList=currentCatchupPrograms; currentPlayIndex=i; currentPlayType="catchup"; playCandidateList([url],currentCatchupChannel.name+" - "+p.title)}

/* ---------- AVPlay + Playback ---------- */
function isTizen(){return !!(window.tizen || (window.webapis&&webapis.avplay))}
function hasAVPlay(){return !!(window.webapis&&webapis.avplay)}
function avplayRect(){try{webapis.avplay.setDisplayRect(0,0,window.innerWidth||1920,window.innerHeight||1080)}catch(e){}}
function avplayClose(){try{webapis.avplay.stop()}catch(e){} try{webapis.avplay.close()}catch(e){} avplayPrepared=false; avplayPlaying=false; avplayTracks=[]}

function avplaySetTrackFriendlyProps(){
  try{webapis.avplay.setStreamingProperty("LISTEN_SPARSE_TRACK","TRUE")}catch(e){}
  try{webapis.avplay.setStreamingProperty("USE_VIDEOMIXER","TRUE")}catch(e){}
  try{webapis.avplay.setStreamingProperty("SET_MODE_4K","TRUE")}catch(e){}
}
function parseTrackInfoObj(t){
  var ti=t.trackInfo||t.extra_info||t.extraInfo||{};
  if(typeof ti==="string"){
    try{ti=JSON.parse(ti)}catch(e){
      var obj={};
      ti.split("|").forEach(function(p){
        var kv=p.split("=");
        if(kv.length>=2)obj[kv[0].trim()]=kv.slice(1).join("=").trim();
      });
      ti=obj;
    }
  }
  return ti||{};
}
function trackNameFromInfo(t,idx,type){
  var ti=parseTrackInfoObj(t);
  return ti.language||ti.lang||ti.title||ti.name||ti.Label||ti.label||ti.fourCC||ti.codec||ti.Codec||((type==="audio"?"Audio ":"Subtitle ")+(idx+1));
}
function getAllAVPlayTracksMultiPass(cb){
  if(!useAVPlay || !hasAVPlay()){ if(cb)cb([]); return; }
  var passes=0, best=[];
  function grab(){
    passes++;
    try{
      var arr=webapis.avplay.getTotalTrackInfo()||[];
      if(arr.length>=best.length)best=arr;
    }catch(e){}
    if(passes<5 && best.length===0){setTimeout(grab,700);return}
    avplayTracks=best||[];
    if(cb)cb(avplayTracks);
  }
  grab();
}

function avplayPlayUrl(url,title,onFail){
  try{
    if(avplayPrepare(url,title))return true;
  }catch(e){}
  if(typeof onFail==="function")onFail();
  return false;
}
function avplayPrepare(url,title){if(!hasAVPlay())return false; try{useAVPlay=true; avplayClose(); webapis.avplay.open(url); webapis.avplay.setListener({onbufferingstart:function(){showLoader(true)},onbufferingcomplete:function(){showLoader(false)},onstreamcompleted:function(){playNext()},onerror:function(e){showLoader(false); retryNextSource(e)}}); avplayRect(); try{webapis.avplay.setStreamingProperty("ADAPTIVE_INFO","BITRATES=20000~10000000|STARTBITRATE=HIGHEST|SKIPBITRATE=LOWEST")}catch(e){} try{webapis.avplay.setStreamingProperty("PREBUFFER_MODE","5000")}catch(e){} avplaySetTrackFriendlyProps(); webapis.avplay.prepareAsync(function(){avplayPrepared=true; try{avplayTracks=webapis.avplay.getTotalTrackInfo()||[]}catch(e){avplayTracks=[]} try{webapis.avplay.play(); avplayPlaying=true}catch(e){} setTimeout(function(){try{avplayTracks=webapis.avplay.getTotalTrackInfo()||[]; console.log("POOMANI_AVPLAY_TRACKS="+JSON.stringify(avplayTracks));}catch(e){}},1500); maybeSwitchToHtml5ForTracks(); clearFocus()},function(e){useAVPlay=false; if(currentSourceCandidateIndex<currentSourceCandidates.length-1)retryNextSource(e); else htmlPlayUrl(url,title)}); return true}catch(e){useAVPlay=false; return false}}
function avplayPauseToggle(){if(!useAVPlay||!hasAVPlay())return false; try{if(avplayPlaying){webapis.avplay.pause(); avplayPlaying=false}else{webapis.avplay.play(); avplayPlaying=true} return true}catch(e){return false}}

function refreshAVPlayTracks(cb){
  if(!useAVPlay || !hasAVPlay()){ if(cb)cb(); return; }
  var pass=0, best=avplayTracks||[];
  function grab(){
    pass++;
    try{
      var arr=webapis.avplay.getTotalTrackInfo()||[];
      if(arr.length>=best.length)best=arr;
      try{console.log("POOMANI_CURRENT_STREAM_INFO="+JSON.stringify(webapis.avplay.getCurrentStreamInfo?webapis.avplay.getCurrentStreamInfo():[]))}catch(x){}
    }catch(e){}
    if(pass<6)setTimeout(grab,500);
    else{avplayTracks=best||[]; if(cb)cb();}
  }
  grab();
}
function avplayTrackList(type){
  var out=[];
  try{
    var arr=avplayTracks&&avplayTracks.length?avplayTracks:(webapis.avplay.getTotalTrackInfo()||[]);
    arr.forEach(function(t,n){
      var ti=parseTrackInfoObj(t);
      var raw=JSON.stringify(t).toUpperCase();
      var kind=String(t.type||t.trackType||t.track_type||ti.type||ti.trackType||ti.track_type||"").toUpperCase();
      var idx=(t.index!==undefined?t.index:(t.trackIndex!==undefined?t.trackIndex:(t.track_index!==undefined?t.track_index:n)));

      var isAudio=kind.indexOf("AUDIO")>=0 || raw.indexOf("AUDIO")>=0 || raw.indexOf("A_")>=0 || raw.indexOf("MP4A")>=0 || raw.indexOf("AAC")>=0 || raw.indexOf("AC3")>=0 || raw.indexOf("EAC3")>=0;
      var isText=kind.indexOf("TEXT")>=0 || kind.indexOf("SUBTITLE")>=0 || raw.indexOf("SUBTITLE")>=0 || raw.indexOf("TIMEDTEXT")>=0 || raw.indexOf("TEXT")>=0 || raw.indexOf("SRT")>=0 || raw.indexOf("VTT")>=0;

      if(type==="audio"&&isAudio)out.push({source:"avplay",index:idx,type:t.type||t.trackType||"AUDIO",name:trackNameFromInfo(t,out.length,"audio"),raw:t});
      if(type==="subtitle"&&isText)out.push({source:"avplay",index:idx,type:t.type||t.trackType||"TEXT",name:trackNameFromInfo(t,out.length,"subtitle"),raw:t});
    });
  }catch(e){}
  return out;
}
function avplaySelectTrack(t){
  try{webapis.avplay.setSilentSubtitle(false)}catch(e){}
  var idx=parseInt(t.index,10);
  var rawType=t.type || (t.raw&&(t.raw.type||t.raw.trackType||t.raw.track_type));
  var typeList=trackMode==="audio"
    ? [rawType,"AUDIO","Audio","audio"]
    : [rawType,"TEXT","SUBTITLE","Subtitle","subtitle","TimedText"];
  var indexList=[idx];
  if(t.raw){
    ["index","trackIndex","track_index","id"].forEach(function(k){
      if(t.raw[k]!==undefined)indexList.push(parseInt(t.raw[k],10));
    });
  }
  indexList=indexList.filter(function(x,i,a){return !isNaN(x)&&a.indexOf(x)===i});
  for(var ti=0;ti<typeList.length;ti++){
    if(typeList[ti]===undefined || typeList[ti]===null || typeList[ti]==="")continue;
    for(var ii=0;ii<indexList.length;ii++){
      try{
        webapis.avplay.setSelectTrack(typeList[ti],indexList[ii]);
        toast(t.name);
        return true;
      }catch(e){}
    }
  }
  toast("Track switch failed");
  return false;
}
function avplaySetSubtitleOff(){try{webapis.avplay.setSilentSubtitle(true)}catch(e){} toast("Subtitles off")}
function liveUrlCandidates(ch){if(ch.url)return [ch.url]; var base=server.replace(/\/$/,"")+"/live/"+username+"/"+password+"/"+ch.stream_id; var ext=String(ch.container_extension||ch.stream_type||"").toLowerCase(); var list=[]; if(ext&&ext!=="live"&&ext!=="ts")list.push(base+"."+ext); list.push(base+".ts",base+".m3u8",base+".mp4"); return unique(list)}
function movieUrlCandidates(m){
  var base=server.replace(/\/$/,"")+"/movie/"+username+"/"+password+"/"+m.stream_id;
  var ext=String(m.container_extension||m.containerExtension||"mp4").toLowerCase();
  var list=[];
  if(m.url)list.push(m.url);
  if(m.direct_source)list.push(m.direct_source);
  list.push(base+"."+ext,base+".mp4",base+".mkv",base+".avi",base+".ts",base+".m3u8");
  return unique(list);
}
function episodeUrlCandidates(url){
  if(!url)return [];
  var list=[url];
  var no=url.replace(/\.[a-z0-9]+(\?.*)?$/i,"");
  list.push(no+".mp4",no+".mkv",no+".avi",no+".ts",no+".m3u8");
  return unique(list);
}

function playEpisode(i){
  i=parseInt(i,10);
  var ep=currentEpisodes[i];
  if(!ep){toast("Episode not found");return;}

  currentPlayList=currentEpisodes;
  currentPlayIndex=i;
  currentPlayType="series";

  var ext=ep.container_extension||ep.containerExtension||ep.container_ext||"mp4";
  var eid=ep.id||ep.episode_id||ep.stream_id;
  var url=ep.url||ep.direct_source||ep.stream_url||ep.play_url||"";

  if(!url && eid){
    url=server.replace(/\/$/,"")+"/series/"+username+"/"+password+"/"+eid+"."+ext;
  }

  if(!url){
    toast("Episode URL missing");
    return;
  }

  playCandidateList(episodeUrlCandidates(url),ep.title||ep.name||"Episode");
}


function normalizePlayUrlCandidate(c){
  if(!c)return "";
  if(typeof c==="string")return c;
  if(typeof c==="object"){
    return c.url||c.play_url||c.stream_url||c.movie_url||c.series_url||c.cmd||c.link||c.src||"";
  }
  return String(c||"");
}
function maybeSwitchToHtml5ForTracks(){
  if(!useAVPlay || !currentUrl)return;
  setTimeout(function(){
    try{
      var av=avplayTrackList("audio");
      if(av.length===0 && (currentPlayType==="movie" || currentPlayType==="series")){
        console.log("No AVPlay audio tracks, keeping AVPlay playback. Use HTML5 fallback from Audio popup if needed.");
      }
    }catch(e){}
  },6000);
}


function channelRenderer(c,i){
  return '<div class="item focusable channel-row" data-channel-index="'+i+'">'+safeImg(c.stream_icon||c.logo,"logo")+'<span>'+esc(c.name||"Channel")+'</span></div>';
}
function movieRenderer(m,i){
  return '<div class="item focusable" data-movie-index="'+i+'">'+safeImg(m.stream_icon||m.cover||m.movie_image,"poster-small")+'<span>'+esc(m.name||"Movie")+'</span></div>';
}
function episodeRenderer(e,idx){
  var title=e.title||e.name||("Episode "+(idx+1));
  return '<div class="item focusable" data-episode-index="'+idx+'">S'+esc(e.season||e._season||"")+' E'+esc(e.episode_num||e.episode||"")+' - '+esc(title)+'</div>';
}

function playCandidateList(list,title){
  currentCandidateList=list||[];
  currentCandidateIndex=0;
  currentSourceCandidates=currentCandidateList;
  currentSourceCandidateIndex=0;
  currentSourceTitle=title||"Playing";
  retryingSource=false;

  if(!currentCandidateList.length){
    toast("No playable URL");
    return;
  }

  var url=normalizePlayUrlCandidate(currentCandidateList[0]);
  if(!url){
    toast("Stream URL missing");
    return;
  }

  currentUrl=url;
  playUrl(url,currentSourceTitle);
}
function retryNextSource(reason){
  if(retryingSource)return;
  retryingSource=true;
  setTimeout(function(){
    retryingSource=false;

    var list=(currentCandidateList&&currentCandidateList.length)?currentCandidateList:currentSourceCandidates;
    if(!list || !list.length){
      toast("No alternate source");
      return;
    }

    currentSourceCandidateIndex++;
    currentCandidateIndex=currentSourceCandidateIndex;

    if(currentSourceCandidateIndex>=list.length){
      toast("All source options failed");
      return;
    }

    var url=normalizePlayUrlCandidate(list[currentSourceCandidateIndex]);
    if(!url){
      retryNextSource("empty_url");
      return;
    }

    currentUrl=url;
    toast("Retrying source "+(currentSourceCandidateIndex+1)+"/"+list.length);
    playUrl(url,currentSourceTitle||"Playing");
  },700);
}
function playLive(i){currentPlayList=currentChannels.length?currentChannels:catchupChannels; currentPlayIndex=i; currentPlayType="live"; var ch=currentPlayList[i]; if(!ch){toast("Channel not found");return} playCandidateList(liveUrlCandidates(ch),ch.name)}
function playMovie(i){
  i=parseInt(i,10);
  currentPlayList=currentMovies;
  currentPlayIndex=i;
  currentPlayType="movie";
  currentMovieInfo=null;
  var m=currentMovies[i];
  if(!m){toast("Movie not found");return;}
  playCandidateList(movieUrlCandidates(m),m.name||"Movie");
}
function htmlPlayUrl(url,title){
  useAVPlay=false;
  try{avplayClose()}catch(e){}
  var v=$("videoPlayer");
  if(!v){
    toast("Video element missing");
    return;
  }

  try{
    v.style.display="block";
    v.style.objectFit=fitMode;
    v.pause();
    v.removeAttribute("src");
    v.load();
    v.src=url;
    v.onerror=function(){toast("HTML player error, trying another source");retryNextSource("html_error")};
    v.onloadedmetadata=function(){try{refreshHtml5TracksDelayed()}catch(e){}};
    v.onloadeddata=function(){try{refreshHtml5TracksDelayed()}catch(e){}};
    v.oncanplay=function(){try{refreshHtml5TracksDelayed()}catch(e){}};
    v.onplay=function(){try{refreshHtml5TracksDelayed()}catch(e){}};
  }catch(e){
    toast("HTML player setup failed");
  }

  if($("playerTitle"))$("playerTitle").textContent=title||"Playing";
  showPage("playerPage");
  startContinueTimer();

  setTimeout(function(){
    try{
      var p=v.play();
      if(p&&p.catch)p.catch(function(){toast("Press OK Play/Pause")});
    }catch(e){
      toast("Playback start failed");
    }
    clearFocus();
  },250);

  try{refreshHtml5TracksDelayed()}catch(e){}
}

function debugTrackToastAfterPlay(){
  setTimeout(function(){
    try{
      if(useAVPlay&&hasAVPlay()){
        avplayTracks=webapis.avplay.getTotalTrackInfo()||avplayTracks||[];
        console.log("POOMANI_TRACK_DEBUG="+JSON.stringify(avplayTracks));
      }
    }catch(e){}
  },8000);
}

function startContinueTimer(){
  try{if(window.__poomaniContinueTimer)clearInterval(window.__poomaniContinueTimer)}catch(e){}
  window.__poomaniContinueTimer=setInterval(function(){
    try{
      if(currentPlayType!=="movie" && currentPlayType!=="series")return;
      var v=$("videoPlayer");
      var pos=0,dur=0;
      if(useAVPlay&&hasAVPlay()){
        try{pos=(webapis.avplay.getCurrentTime?webapis.avplay.getCurrentTime():0)/1000}catch(e){}
        try{dur=(webapis.avplay.getDuration?webapis.avplay.getDuration():0)/1000}catch(e){}
      }else if(v){pos=v.currentTime||0; dur=v.duration||0;}
      if(pos>20)saveContinue(currentPlayType,currentPlayList[currentPlayIndex],currentUrl,pos,dur);
    }catch(e){}
  },10000);
}

function playUrl(url,title){
  currentUrl=url;
  if($("playerTitle"))$("playerTitle").textContent=title||"Playing";
  showPage("playerPage");

  var v=$("videoPlayer");
  try{
    if(v){
      v.pause();
      v.removeAttribute("src");
      v.load();
      v.style.objectFit=fitMode;
      v.style.display=hasAVPlay()?"none":"block";
    }
  }catch(e){}

  try{
    if(hasAVPlay()){
      if(avplayPrepare(url,title)){debugTrackToastAfterPlay();return;}
    }
  }catch(e){
    console.log("AVPlay start failed",e);
  }

  htmlPlayUrl(url,title);
  debugTrackToastAfterPlay();
}
function playNext(){
  if(!currentPlayList.length)return;
  currentPlayIndex=(currentPlayIndex+1)%currentPlayList.length;
  if(currentPlayType==="catchup")playCatchupProgram(currentPlayIndex);
  else if(currentPlayType==="movie")playMovie(currentPlayIndex);
  else if(currentPlayType==="series")playEpisode(currentPlayIndex);
  else playLive(currentPlayIndex);
}
function playPrev(){
  if(!currentPlayList.length)return;
  currentPlayIndex=(currentPlayIndex-1+currentPlayList.length)%currentPlayList.length;
  if(currentPlayType==="catchup")playCatchupProgram(currentPlayIndex);
  else if(currentPlayType==="movie")playMovie(currentPlayIndex);
  else if(currentPlayType==="series")playEpisode(currentPlayIndex);
  else playLive(currentPlayIndex);
}
function playPause(){if(useAVPlay&&avplayPauseToggle())return; var v=$("videoPlayer"); try{v.paused?v.play():v.pause()}catch(e){}}
function fit(){fitMode=fitMode==="contain"?"cover":"contain"; try{$("videoPlayer").style.objectFit=fitMode}catch(e){} if(useAVPlay)avplayRect(); toast(fitMode==="cover"?"Fill screen":"Fit screen")}
function fullscreen(){var p=$("playerWrapper"); try{if(p.requestFullscreen)p.requestFullscreen(); else if(p.webkitRequestFullscreen)p.webkitRequestFullscreen()}catch(e){} toast("Fullscreen")}
function closePlayer(){if(useAVPlay)avplayClose(); try{$("videoPlayer").pause()}catch(e){} showPage(lastSectionPage||"homePage")}

/* ---------- Tracks / Search ---------- */
function normalizeTrackName(x,idx,type){x=x||{}; return x.name||x.title||x.language||x.lang||x.codec_name||x.label||((type==="audio"?"Audio ":"Subtitle ")+(idx+1))}



function deepFindTrackArrays(obj,type){
  var found=[];
  var seen=[];
  function looksAudioKey(k){k=String(k||"").toLowerCase(); return k==="audio"||k==="audios"||k==="audio_tracks"||k==="audiotracks"||k==="tracks_audio"||k.indexOf("audio")>=0;}
  function looksSubKey(k){k=String(k||"").toLowerCase(); return k==="subtitle"||k==="subtitles"||k==="subs"||k==="subtitle_tracks"||k.indexOf("subtitle")>=0||k.indexOf("subtitles")>=0;}
  function walk(o,key){
    if(!o || typeof o!=="object")return;
    if(seen.indexOf(o)>=0)return;
    seen.push(o);
    if(Array.isArray(o)){
      if((type==="audio" && looksAudioKey(key)) || (type==="subtitle" && looksSubKey(key))){
        o.forEach(function(x){found.push(x)});
      }else{
        o.forEach(function(x){walk(x,key)});
      }
      return;
    }
    Object.keys(o).forEach(function(k){
      var v=o[k];
      if(Array.isArray(v) && ((type==="audio"&&looksAudioKey(k))||(type==="subtitle"&&looksSubKey(k)))){
        v.forEach(function(x){found.push(x)});
      }else{
        walk(v,k);
      }
    });
  }
  walk(obj,"");
  return found;
}
function normalizeServerTrack(x,i,type){
  if(typeof x==="string")x={url:x,name:x};
  x=x||{};
  var name=x.name||x.title||x.label||x.language||x.lang||x.display_name||x.codec_name||((type==="audio"?"Audio ":"Subtitle ")+(i+1));
  var url=x.url||x.file||x.path||x.link||x.src||x.stream_url||x.play_url||x.uri||"";
  var index=x.index!==undefined?x.index:(x.id!==undefined?x.id:i);
  return {source:"server",index:index,name:name,url:url,raw:x};
}
function hlsAbs(base,u){
  if(!u)return "";
  if(/^https?:\/\//i.test(u))return u;
  if(u.indexOf("//")===0)return location.protocol+u;
  try{return new URL(u,base).href}catch(e){
    var b=String(base||"").split("?")[0];
    return b.substring(0,b.lastIndexOf("/")+1)+u;
  }
}
async function fetchHlsAudioTracks(url){
  var out=[];
  if(!url || url.indexOf(".m3u8")<0)return out;
  try{
    var txt=await fetch(url).then(function(r){return r.text()});
    var lines=txt.split(/\r?\n/);
    lines.forEach(function(line){
      if(line.indexOf("#EXT-X-MEDIA")===0 && /TYPE=AUDIO/i.test(line)){
        var obj={};
        line.replace(/([A-Z0-9-]+)=("[^"]*"|[^,]*)/gi,function(_,k,v){
          obj[k]=String(v||"").replace(/^"|"$/g,"");
        });
        var uri=obj.URI?hlsAbs(url,obj.URI):"";
        out.push({source:"hls",index:out.length,name:obj.NAME||obj.LANGUAGE||("Audio "+(out.length+1)),url:uri,group:obj["GROUP-ID"]||"",raw:obj});
      }
    });
  }catch(e){}
  return out;
}
async function getCurrentServerInfoForTracks(){
  try{
    if(currentPlayType==="movie"){
      var m=currentPlayList[currentPlayIndex]||{};
      var id=m.stream_id||m.id;
      if(id){
        if(!lastVodInfoCache[id])lastVodInfoCache[id]=await api("get_vod_info","vod_id="+encodeURIComponent(id));
        currentMovieInfo=lastVodInfoCache[id];
        return currentMovieInfo;
      }
    }
    if(currentPlayType==="series"){
      var ep=currentPlayList[currentPlayIndex]||{};
      currentEpisodeInfo=ep;
      return ep;
    }
  }catch(e){}
  return null;
}
async function collectServerTracks(type){
  var info=await getCurrentServerInfoForTracks();
  var item=(currentPlayList&&currentPlayList[currentPlayIndex])||{};
  var arr=[];
  [item,info,info&&info.info,info&&info.movie_data].forEach(function(o){
    deepFindTrackArrays(o,type).forEach(function(x){arr.push(x)});
  });
  var norm=arr.map(function(x,i){return normalizeServerTrack(x,i,type)}).filter(function(t){return type==="audio" ? true : true});
  return norm;
}
function applyServerTrack(t){
  if(!t)return false;
  if(trackMode==="subtitle"){
    if(!t.url){toast("Subtitle URL not available");return false}
    try{
      var v=$("videoPlayer");
      var old=$("dynamicSubtitleTrack"); if(old)old.remove();
      var tr=document.createElement("track");
      tr.id="dynamicSubtitleTrack"; tr.kind="subtitles"; tr.label=t.name; tr.srclang=(t.raw&&(t.raw.lang||t.raw.language))||"en"; tr.src=t.url; tr.default=true;
      v.appendChild(tr);
      setTimeout(function(){try{for(var i=0;i<v.textTracks.length;i++)v.textTracks[i].mode=(i===v.textTracks.length-1)?"showing":"disabled"}catch(e){}},500);
      toast(t.name); return true;
    }catch(e){toast("Subtitle load failed");return false}
  }
  if(trackMode==="audio"){
    if(t.url){
      // Some Xtream/HLS providers expose each audio as a separate media URI. Play it directly if provided.
      currentUrl=t.url;
      playUrl(t.url,currentSourceTitle||t.name||"Audio");
      toast(t.name);
      return true;
    }
    // If server only exposes metadata without URL, AVPlay/HTML cannot switch it.
    toast("Audio track found but no playable URL exposed");
    return false;
  }
  return false;
}
function applyHlsAudioTrack(t){
  if(!t || !t.url){toast("HLS audio has no separate URL");return false}
  // HLS alternate audio URI is often audio-only, so direct play may not include video.
  // We expose it only if server provides a playable variant. Otherwise Samsung must switch internally.
  toast("HLS audio track found: "+t.name);
  return false;
}

async function loadServerTracks(type){
  var tracks=[];
  try{
    tracks=tracks.concat(await collectServerTracks(type));
  }catch(e){}

  try{
    if(type==="audio" && currentUrl && currentUrl.indexOf(".m3u8")>=0){
      tracks=tracks.concat(await fetchHlsAudioTracks(currentUrl));
    }
  }catch(e){}

  // de-duplicate by name/url/index/source
  var seen={}, out=[];
  tracks.forEach(function(t,i){
    if(!t)return;
    if(!t.name)t.name=(type==="audio"?"Audio ":"Subtitle ")+(i+1);
    var key=(t.source||"")+"|"+(t.name||"")+"|"+(t.url||"")+"|"+(t.index||"");
    if(!seen[key]){seen[key]=1;out.push(t)}
  });
  return out;
}

function normalizeTrackLabel(t, i, kind){
  var lang=t.language||t.lang||"";
  var label=t.label||t.name||t.title||"";
  var id=t.id||"";
  var s=(label||lang||id||((kind==="audio"?"Audio ":"Subtitle ")+(i+1)));
  return s;
}
function collectHtml5AudioTracks(){
  var out=[], v=$("videoPlayer");
  if(!v)return out;
  try{
    var list=v.audioTracks||[];
    for(var i=0;i<list.length;i++){
      out.push({source:"html5-audioTracks",index:i,name:normalizeTrackLabel(list[i],i,"audio"),raw:list[i]});
    }
  }catch(e){}
  try{
    if(!out.length && typeof v.getTracks==="function"){
      var tracks=v.getTracks()||[];
      for(var j=0;j<tracks.length;j++){
        var tr=tracks[j];
        var kind=String(tr.kind||tr.type||"").toLowerCase();
        if(kind.indexOf("audio")>=0)out.push({source:"html5-getTracks",index:j,name:normalizeTrackLabel(tr,out.length,"audio"),raw:tr});
      }
    }
  }catch(e){}
  return out;
}
function collectHtml5SubtitleTracks(){
  var out=[], v=$("videoPlayer");
  if(!v)return out;
  try{
    var list=v.textTracks||[];
    for(var i=0;i<list.length;i++){
      out.push({source:"html5-textTracks",index:i,name:normalizeTrackLabel(list[i],i,"subtitle"),raw:list[i]});
    }
  }catch(e){}
  try{
    if(!out.length && typeof v.getTracks==="function"){
      var tracks=v.getTracks()||[];
      for(var j=0;j<tracks.length;j++){
        var tr=tracks[j];
        var kind=String(tr.kind||tr.type||"").toLowerCase();
        if(kind.indexOf("text")>=0 || kind.indexOf("subtitle")>=0 || kind.indexOf("caption")>=0){
          out.push({source:"html5-getTracks",index:j,name:normalizeTrackLabel(tr,out.length,"subtitle"),raw:tr});
        }
      }
    }
  }catch(e){}
  return out;
}
function refreshHtml5TracksDelayed(){
  setTimeout(function(){try{availableAudioTracks=collectHtml5AudioTracks();availableSubtitleTracks=collectHtml5SubtitleTracks()}catch(e){}},1000);
  setTimeout(function(){try{availableAudioTracks=collectHtml5AudioTracks();availableSubtitleTracks=collectHtml5SubtitleTracks()}catch(e){}},3000);
  setTimeout(function(){try{availableAudioTracks=collectHtml5AudioTracks();availableSubtitleTracks=collectHtml5SubtitleTracks()}catch(e){}},6000);
}
function selectHtml5AudioTrack(t){
  var v=$("videoPlayer"); if(!v)return false;
  try{
    var list=v.audioTracks||[];
    for(var i=0;i<list.length;i++)list[i].enabled=(i===parseInt(t.index,10));
    toast(t.name); return true;
  }catch(e){}
  try{
    if(t.raw && "enabled" in t.raw){ t.raw.enabled=true; toast(t.name); return true; }
  }catch(e){}
  return false;
}
function selectHtml5SubtitleTrack(t){
  var v=$("videoPlayer"); if(!v)return false;
  try{
    var list=v.textTracks||[];
    for(var i=0;i<list.length;i++)list[i].mode=(i===parseInt(t.index,10))?"showing":"disabled";
    toast(t.name); return true;
  }catch(e){}
  try{
    if(t.raw && "mode" in t.raw){ t.raw.mode="showing"; toast(t.name); return true; }
  }catch(e){}
  return false;
}


function safeJsonString(o){
  try{return JSON.stringify(o)}catch(e){return String(o)}
}
function isLikelyVideoTrackRaw(t){
  var s=safeJsonString(t).toUpperCase();
  return s.indexOf("VIDEO")>=0 || s.indexOf("H264")>=0 || s.indexOf("HEVC")>=0 || s.indexOf("AVC")>=0 || s.indexOf("V_MPEG")>=0;
}
function isLikelyAudioTrackRaw(t){
  var s=safeJsonString(t).toUpperCase();
  return s.indexOf("AUDIO")>=0 || s.indexOf("AAC")>=0 || s.indexOf("MP4A")>=0 || s.indexOf("AC3")>=0 || s.indexOf("EAC3")>=0 || s.indexOf("A_")>=0 || s.indexOf("MPEG4-GENERIC")>=0;
}
function avplayRawAudioFallback(){
  var out=[];
  try{
    var arr=webapis.avplay.getTotalTrackInfo()||avplayTracks||[];
    arr.forEach(function(t,n){
      if(isLikelyAudioTrackRaw(t) || (!isLikelyVideoTrackRaw(t) && n>0)){
        var idx=(t.index!==undefined?t.index:(t.trackIndex!==undefined?t.trackIndex:(t.track_index!==undefined?t.track_index:n)));
        out.push({source:"avplay",index:idx,type:"AUDIO",name:trackNameFromInfo(t,out.length,"audio"),raw:t});
      }
    });
  }catch(e){}
  return out;
}
function avplayRawSubtitleFallback(){
  var out=[];
  try{
    var arr=webapis.avplay.getTotalTrackInfo()||avplayTracks||[];
    arr.forEach(function(t,n){
      var s=safeJsonString(t).toUpperCase();
      if(s.indexOf("SUBTITLE")>=0 || s.indexOf("TEXT")>=0 || s.indexOf("SRT")>=0 || s.indexOf("VTT")>=0){
        var idx=(t.index!==undefined?t.index:(t.trackIndex!==undefined?t.trackIndex:(t.track_index!==undefined?t.track_index:n)));
        out.push({source:"avplay",index:idx,type:"TEXT",name:trackNameFromInfo(t,out.length,"subtitle"),raw:t});
      }
    });
  }catch(e){}
  return out;
}
async function scanAllTracks(type){
  var av=[];
  try{av=useAVPlay?bundleBuildAvplayTracks(type):[]}catch(e){}
  if(!av.length){
    try{av=useAVPlay?avplayTrackList(type):[]}catch(e){}
  }
  if(type==="audio" && (!av || !av.length)){
    try{av=avplayRawAudioFallback()}catch(e){}
  }
  if(type==="subtitle" && (!av || !av.length)){
    try{av=avplayRawSubtitleFallback()}catch(e){}
  }
  var html5=[];
  try{html5=type==="audio"?collectHtml5AudioTracks():collectHtml5SubtitleTracks()}catch(e){}
  var serverTracks=[];
  try{serverTracks=await loadServerTracks(type)}catch(e){}
  var list=(av||[]).concat(html5||[]).concat(serverTracks||[]);
  var seen={}, out=[];
  list.forEach(function(t,i){
    if(!t)return;
    var key=(t.source||"")+"|"+(t.type||"")+"|"+(t.absoluteIndex!==undefined?t.absoluteIndex:(t.index!==undefined?t.index:i))+"|"+(t.name||"")+"|"+(t.url||"");
    if(!seen[key]){seen[key]=1;out.push(t)}
  });
  return out;
}
function forceRescanTracks(){
  openTrackModal(trackMode||"audio");
}


function bundleParseTrackInfo(t){
  var info=t.track_info||t.trackInfo||t.extra_info||t.extraInfo||"";
  if(typeof info==="string"){
    try{return JSON.parse(info)}catch(e){return {}}
  }
  return info||{};
}
function bundleTrackLabel(t, fallbackType, n){
  var info=bundleParseTrackInfo(t);
  var lang=info.language||info.track_lang||info.lang||info.title||info.name||"";
  if(lang==="und" || lang==="undefined")lang="";
  if(lang)return lang;
  if(fallbackType==="AUDIO")return "Audio "+(n+1);
  if(fallbackType==="TEXT")return "Subtitle "+(n+1);
  return fallbackType+" "+(n+1);
}
function getCurrentStreamBaseMap(){
  var map={AUDIO:0,TEXT:0,VIDEO:0};
  try{
    if(window.webapis&&webapis.avplay&&webapis.avplay.getCurrentStreamInfo){
      var cur=webapis.avplay.getCurrentStreamInfo()||[];
      cur.forEach(function(x){
        var typ=String(x.type||x.trackType||"").toUpperCase();
        var idx=(x.index!==undefined?x.index:(x.trackIndex!==undefined?x.trackIndex:(x.extra_info&&x.extra_info.index)||0));
        if(typ.indexOf("AUDIO")>=0)map.AUDIO=parseInt(idx,10)||0;
        if(typ.indexOf("TEXT")>=0||typ.indexOf("SUBTITLE")>=0)map.TEXT=parseInt(idx,10)||0;
        if(typ.indexOf("VIDEO")>=0)map.VIDEO=parseInt(idx,10)||0;
      });
    }
  }catch(e){}
  return map;
}
function bundleBuildAvplayTracks(type){
  var out=[];
  try{
    var total=webapis.avplay.getTotalTrackInfo?webapis.avplay.getTotalTrackInfo():[];
    avplayTracks=total||[];
    var base=getCurrentStreamBaseMap();
    (total||[]).forEach(function(t,n){
      var typ=String(t.type||t.trackType||t.track_type||"").toUpperCase();
      var raw=JSON.stringify(t).toUpperCase();
      if(!typ){
        if(raw.indexOf("AUDIO")>=0||raw.indexOf("AAC")>=0||raw.indexOf("AC3")>=0||raw.indexOf("MP4A")>=0)typ="AUDIO";
        else if(raw.indexOf("TEXT")>=0||raw.indexOf("SUBTITLE")>=0||raw.indexOf("SRT")>=0||raw.indexOf("VTT")>=0)typ="TEXT";
        else if(raw.indexOf("VIDEO")>=0||raw.indexOf("H264")>=0||raw.indexOf("HEVC")>=0)typ="VIDEO";
      }
      var want=(type==="audio"&&typ==="AUDIO")||(type==="subtitle"&&(typ==="TEXT"||typ==="SUBTITLE"));
      if(!want)return;
      var absolute=(t.index!==undefined?t.index:(t.trackIndex!==undefined?t.trackIndex:(t.track_index!==undefined?t.track_index:n)));
      var relative=absolute;
      if(type==="audio")relative=absolute-(base.AUDIO||0);
      if(type==="subtitle")relative=absolute-(base.TEXT||0);
      if(relative<0)relative=absolute;
      out.push({
        source:"avplay-bundle",
        index:relative,
        absoluteIndex:absolute,
        type:(type==="audio"?"AUDIO":"TEXT"),
        name:bundleTrackLabel(t,(type==="audio"?"AUDIO":"TEXT"),out.length),
        raw:t
      });
    });
  }catch(e){}
  return out;
}
function bundleSelectAvplayTrack(t){
  var rel=parseInt(t.index,10);
  var abs=parseInt(t.absoluteIndex,10);
  var typ=(trackMode==="audio"?"AUDIO":"TEXT");
  var tries=[];
  // Working bundle style: selectTrack(type, relativeIndex, 0)
  tries.push(function(){return webapis.avplay.selectTrack(typ, rel, 0)});
  tries.push(function(){return webapis.avplay.selectTrack(typ, abs, 0)});
  // Tizen documented style on many models:
  tries.push(function(){return webapis.avplay.setSelectTrack(typ, rel)});
  tries.push(function(){return webapis.avplay.setSelectTrack(typ, abs)});
  // Some firmwares accept lower/alternate names:
  tries.push(function(){return webapis.avplay.setSelectTrack(trackMode==="audio"?"Audio":"Subtitle", rel)});
  tries.push(function(){return webapis.avplay.setSelectTrack(trackMode==="audio"?"audio":"subtitle", rel)});
  for(var i=0;i<tries.length;i++){
    try{tries[i](); toast(t.name); return true}catch(e){}
  }
  toast("Track switch failed");
  return false;
}

async function openTrackModal(type){
  trackMode=type;
  if($("trackModalTitle"))$("trackModalTitle").textContent=type==="audio"?"Audio Tracks":"Subtitles";
  if($("trackList"))$("trackList").innerHTML='<div class="track-item">Scanning tracks, please wait...</div>';
  $("trackModal").classList.remove("hidden");

  refreshAVPlayTracks(async function(){
    var list=await scanAllTracks(type);

    if(type==="subtitle")list.unshift({source:"off",index:-1,name:"Subtitles Off"});
    if(type==="audio")availableAudioTracks=list; else availableSubtitleTracks=list;

    var rawCount=(avplayTracks||[]).length;
    var htmlCount=0;
    try{htmlCount=(type==="audio"?collectHtml5AudioTracks():collectHtml5SubtitleTracks()).length}catch(e){}
    var serverCount=0;
    try{serverCount=(await loadServerTracks(type)).length}catch(e){}

    if(!list.length || (type==="subtitle" && list.length===1)){
      var msg=type==="audio"
        ? "No selectable audio tracks found. AVPlay raw: "+rawCount+", HTML5: "+htmlCount+", Server: "+serverCount+"."
        : "No selectable subtitles found. AVPlay raw: "+rawCount+", HTML5: "+htmlCount+", Server: "+serverCount+".";
      $("trackList").innerHTML=
        '<div class="track-item focusable" data-action="forceRescanTracks">↻ Rescan tracks</div>'+
        '<div class="track-item focusable" data-action="closeTrackModal">'+msg+' Press OK to close.</div>';
      focusFirst(); return;
    }

    $("trackList").innerHTML=
      '<div class="track-item focusable" data-action="forceRescanTracks">↻ Rescan tracks <small>(AVPlay raw '+rawCount+', HTML5 '+htmlCount+', Server '+serverCount+')</small></div>'+
      list.map(function(t,i){
        var tag=(t.source==="avplay"||t.source==="avplay-bundle")?" <small>(AVPlay)</small>":
          (t.source&&String(t.source).indexOf("html5")===0?" <small>(HTML5)</small>":
          (t.source==="hls"?" <small>(HLS)</small>":
          (t.source==="server"?" <small>(server)</small>":"")));
        return '<div class="track-item focusable" data-track-index="'+i+'">'+esc(t.name)+tag+'</div>';
      }).join("");
    focusFirst();
  });
}
function closeTrackModal(){$("trackModal").classList.add("hidden"); clearFocus()}
function selectTrack(i){
  var list=trackMode==="audio"?availableAudioTracks:availableSubtitleTracks;
  var t=list[i]; if(!t)return;

  if(t.source==="off"){
    try{var v=$("videoPlayer"); if(v&&v.textTracks){for(var k=0;k<v.textTracks.length;k++)v.textTracks[k].mode="disabled"}}catch(e){}
    try{webapis.avplay.setSilentSubtitle(true)}catch(e){}
    closeTrackModal(); return;
  }

  if(t.source==="avplay-bundle")bundleSelectAvplayTrack(t);
  else if(t.source==="avplay")avplaySelectTrack(t);
  else if(t.source && String(t.source).indexOf("html5-audio")===0)selectHtml5AudioTrack(t);
  else if(t.source && (String(t.source).indexOf("html5-text")===0 || String(t.source).indexOf("html5-getTracks")===0))selectHtml5SubtitleTrack(t);
  else if(t.source==="server")applyServerTrack(t);
  else if(t.source==="hls")applyHlsAudioTrack(t);
  else toast("Unsupported track source");

  closeTrackModal();
}
function audio(){openTrackModal("audio")}
function subs(){openTrackModal("subtitle")}
function openSearch(){$("searchModal").classList.remove("hidden"); setTimeout(function(){focusIndex=0; applyFocus(); try{$("searchInput").focus()}catch(e){}},50)}
function closeSearch(){$("searchModal").classList.add("hidden"); focusFirst()}
function doSearch(q){q=String(q||"").toLowerCase(); var res=[]; liveChannelsAll.forEach(function(x){if((x.name||"").toLowerCase().indexOf(q)>=0)res.push({type:"live",name:x.name,item:x})}); moviesAll.forEach(function(x){if((x.name||"").toLowerCase().indexOf(q)>=0)res.push({type:"movie",name:x.name,item:x})}); seriesAll.forEach(function(x){if((x.name||"").toLowerCase().indexOf(q)>=0)res.push({type:"series",name:x.name,item:x})}); window.searchCache=res; $("searchResults").innerHTML=res.slice(0,80).map(function(r,i){return '<div class="item focusable" data-search-type="'+r.type+'" data-search-index="'+i+'">'+esc(r.type.toUpperCase()+" - "+r.name)+'</div>'}).join("")}
function playSearch(el){var r=(window.searchCache||[])[parseInt(el.dataset.searchIndex,10)]; if(!r)return; closeSearch(); if(r.type==="live"){currentChannels=[r.item]; playLive(0)} else if(r.type==="movie"){currentMovies=[r.item]; playMovie(0)} else{openSeries(); toast("Open series category to view episodes")}}

/* ---------- Actions ---------- */
function handleAction(el){
  var a=el&&el.dataset?el.dataset.action:"";
  if(a==="openUniversalSearch")return openUniversalSearch();
  if(a==="closeUniversalSearch")return closeUniversalSearch();
  if(a==="openContinueAll")return toast("Continue Watching");
  if(el&&el.dataset&&el.dataset.searchIndex)return openSearchResult(parseInt(el.dataset.searchIndex,10));
  if(!el)return; var a=el.dataset.action;
  if(a==="resetApp")return resetAppData(); if(a==="login")return login(); if(a==="logout")return logout(); if(a==="backHome")return showPage("homePage");
  if(a==="openSearch")return openSearch(); if(a==="closeSearch")return closeSearch(); if(a==="clearCache")return clearCache();
  if(a==="savePlaylist")return savePlaylist(); if(a==="activatePlaylist")return activatePlaylist(el.dataset.index); if(a==="deletePlaylist")return deletePlaylist(el.dataset.index); if(a==="toggleDefaultFit")return toggleDefaultFit();
  if(a==="loadMore")return loadMoreList(el.dataset.list);
  if(a==="forceRescanTracks")return forceRescanTracks();
  if(a==="prev")return playPrev(); if(a==="next")return playNext(); if(a==="playPause")return playPause(); if(a==="audio")return audio(); if(a==="subs")return subs(); if(a==="fit")return fit(); if(a==="fullscreen")return fullscreen(); if(a==="closePlayer")return closePlayer(); if(a==="closeTrackModal")return closeTrackModal();
  if(el.dataset.trackIndex)return selectTrack(parseInt(el.dataset.trackIndex,10));
  if(el.dataset.section==="live")return openLive(); if(el.dataset.section==="movies")return openMovies(); if(el.dataset.section==="series")return openSeries(); if(el.dataset.section==="catchup")return openCatchup(); if(el.dataset.section==="settings")return showPage("settingsPage");
  if(el.dataset.catLive)return loadLiveChannels(el.dataset.catLive); if(el.dataset.catMovie)return loadMovies(el.dataset.catMovie); if(el.dataset.catSeries)return loadSeries(el.dataset.catSeries);
  if(el.dataset.liveIndex)return playLive(parseInt(el.dataset.liveIndex,10)); if(el.dataset.movieIndex)return playMovie(parseInt(el.dataset.movieIndex,10)); if(el.dataset.seriesIndex)return openSeriesInfo(parseInt(el.dataset.seriesIndex,10));
  if(el.dataset.catchupChannel)return loadCatchupEpg(parseInt(el.dataset.catchupChannel,10)); if(el.dataset.catchupDate)return loadCatchupDate(el.dataset.catchupDate); if(el.dataset.catchupProgram)return playCatchupProgram(parseInt(el.dataset.catchupProgram,10));
  if(el.dataset.episodeIndex)return playEpisode(parseInt(el.dataset.episodeIndex,10));
  if(el.dataset.episodeUrl){currentPlayType="series"; return playCandidateList(episodeUrlCandidates(el.dataset.episodeUrl),el.dataset.title||"Episode")}
  if(el.dataset.searchType)return playSearch(el);
}
function handleBack(){if(trackOpen())return closeTrackModal(); if(searchOpen())return closeSearch(); if(currentPage==="playerPage")return closePlayer(); if(currentPage!=="homePage"&&currentPage!=="loginPage")return showPage("homePage")}

/* ---------- Startup ---------- */
window.onerror=function(msg,src,line,col,err){toast("JS Error: "+msg+" line "+line,6000); return false};
document.addEventListener("keydown",function(e){var k=e.keyCode; if(k===37){e.preventDefault();moveDir("left")}else if(k===39){e.preventDefault();moveDir("right")}else if(k===38){e.preventDefault();moveDir("up")}else if(k===40){e.preventDefault();moveDir("down")}else if(k===13){e.preventDefault();selectFocused()}else if(k===10009||k===461){e.preventDefault();handleBack()}else if(k===427||k===33){playNext()}else if(k===428||k===34){playPrev()}else if(k===415){playPause()}});
document.addEventListener("click",function(e){var el=e.target.closest(".focusable"); if(el){pressEffect(el); handleAction(el)}});
window.onbeforeunload=function(){try{avplayClose()}catch(e){}};
window.onload=function(){
  try{if(window.tizen&&tizen.tvinputdevice){["MediaPlay","MediaPause","MediaStop","MediaRewind","MediaFastForward","ChannelUp","ChannelDown"].forEach(function(k){try{tizen.tvinputdevice.registerKey(k)}catch(e){}})}}catch(e){}
  loadPlaylistStore();
  if($("searchInput"))$("searchInput").addEventListener("input",function(){doSearch(this.value)});
  var saved=localStorage.getItem("iptvLogin");
  if(saved){try{var s=JSON.parse(saved); applyAccount(s); if($("serverInput"))$("serverInput").value=server; if($("usernameInput"))$("usernameInput").value=username; if($("passwordInput"))$("passwordInput").value=password; showPage("homePage")}catch(e){localStorage.removeItem("iptvLogin"); focusFirst()}}
  else focusFirst();
};

/* expose for debug */
window.PoomaniTV={openLive:openLive,openMovies:openMovies,openSeries:openSeries,playLive:playLive,playMovie:playMovie,playUrl:playUrl};
})();


function pEsc(x){return String(x==null?"":x).replace(/[&<>"']/g,function(c){return {"&":"&amp;","<":"&lt;",">":"&gt;","\"":"&quot;","'":"&#39;"}[c]})}
function pImg(x){return (x&&(x.stream_icon||x.cover||x.movie_image||x.backdrop_path||x.logo))||""}
function pLatestMovies(n){var arr=(window.vodStreams&&window.vodStreams.length?window.vodStreams:(window.currentMovies||[]))||[];return arr.slice(0,n||7)}
function pContinue(n){try{return JSON.parse(localStorage.getItem("poomani_continue_v1")||"[]").slice(0,n||5)}catch(e){return []}}
function premiumHero(action,title,sub,icon,cls){return '<div class="premium-card focusable '+cls+'" role="button" tabindex="0" data-action="'+action+'"><div class="shade"></div><div class="icon">'+icon+'</div><div class="title">'+title+'</div><div class="sub">'+sub+'</div><div class="arrow">›</div></div>'}
function renderPremiumHome(){
  var root=document.getElementById("homePage")||document.getElementById("mainPage")||document.querySelector(".page");
  if(!root||root.dataset.premiumDone==="1")return;
  root.dataset.premiumDone="1"; root.classList.add("premium-home");
  var cont=pContinue(5), latest=pLatestMovies(7);
  var continueHtml=cont.length?cont.map(function(x,i){var pct=x.dur?Math.min(100,Math.round((x.pos/x.dur)*100)):25;return '<div><div class="continue-card focusable" data-continue-index="'+i+'"><div class="play-badge">▶</div><div class="progress"><span style="width:'+pct+'%"></span></div></div><div class="continue-meta">'+pEsc(x.title)+'</div><div class="continue-sub">'+Math.round((x.pos||0)/60)+'m watched</div></div>'}).join(""):'<div class="continue-sub">No continue watching yet</div>';
  var latestHtml=latest.length?latest.map(function(m,i){var im=pImg(m);return '<div class="latest-poster focusable" data-movie-index="'+i+'">'+(im?'<img src="'+pEsc(im)+'" onerror="this.style.display=&quot;none&quot;">':'')+'<div class="name">'+pEsc(m.name||"Movie")+'</div><div class="year">'+pEsc(m.year||m.releaseDate||"")+'</div></div>'}).join(""):'<div class="continue-sub">Movies will appear after loading playlist</div>';
  root.innerHTML='<div class="premium-hero-row">'+premiumHero("live","LIVE TV","1000+ Channels","▣","live-glow")+premiumHero("movies","MOVIES","Latest Movies","●","movie-glow")+premiumHero("series","SERIES","Popular Series","▻","series-glow")+premiumHero("catchup","CATCHUP","EPG Replay","◫","catchup-glow")+'</div><div class="home-section-head"><div class="home-section-title">Continue Watching</div><div class="view-all-btn focusable" data-action="openContinueAll">View All ›</div></div><div class="poster-row">'+continueHtml+'</div><div class="home-section-head"><div class="home-section-title">Latest Movies</div><div class="view-all-btn focusable" data-action="movies">View All ›</div></div><div class="movie-poster-row">'+latestHtml+'</div>';
  if(typeof focusFirst==="function")focusFirst();
}
function openUniversalSearch(){var old=document.getElementById("universalSearchOverlay"); if(old)old.remove();var div=document.createElement("div");div.id="universalSearchOverlay";div.className="universal-search-overlay";div.innerHTML='<div class="universal-search-box"><input id="universalSearchInput" placeholder="Search Live TV, Movies, Series..." autocomplete="off"><button class="view-all-btn focusable" data-action="closeUniversalSearch">Close</button></div><div id="universalSearchResults" class="universal-search-results"></div>';document.body.appendChild(div);var inp=document.getElementById("universalSearchInput");inp.focus();inp.addEventListener("input",function(){renderUniversalSearchResults(inp.value)});renderUniversalSearchResults("")}
function closeUniversalSearch(){var o=document.getElementById("universalSearchOverlay");if(o)o.remove();if(typeof focusFirst==="function")focusFirst()}
function buildUniversalIndex(){var out=[];try{(window.liveChannels||window.currentChannels||[]).forEach(function(x){out.push({type:"Live TV",name:x.name||"",item:x})})}catch(e){}try{(window.vodStreams||window.currentMovies||[]).forEach(function(x){out.push({type:"Movie",name:x.name||"",item:x})})}catch(e){}try{(window.seriesStreams||window.currentSeries||[]).forEach(function(x){out.push({type:"Series",name:x.name||"",item:x})})}catch(e){}return out}
function renderUniversalSearchResults(q){var box=document.getElementById("universalSearchResults");if(!box)return;q=String(q||"").toLowerCase().trim();var arr=buildUniversalIndex();if(q)arr=arr.filter(function(x){return String(x.name).toLowerCase().indexOf(q)>=0});arr=arr.slice(0,80);window.__universalSearchResults=arr;box.innerHTML=arr.map(function(x,i){return '<div class="search-result-card focusable" data-search-index="'+i+'"><div class="search-result-type">'+pEsc(x.type)+'</div><div class="search-result-name">'+pEsc(x.name)+'</div></div>'}).join("")||'<div class="continue-sub">Type to search all Live TV, Movies and Series</div>'}
function openSearchResult(i){var r=(window.__universalSearchResults||[])[i];if(!r)return;closeUniversalSearch();if(r.type==="Live TV"&&typeof playChannel==="function"){var a=(window.liveChannels||window.currentChannels||[]),idx=a.indexOf(r.item);if(idx>=0)return playChannel(idx)}if(r.type==="Movie"&&typeof playMovie==="function"){window.currentMovies=window.vodStreams&&window.vodStreams.length?window.vodStreams:window.currentMovies;var mi=window.currentMovies.indexOf(r.item);if(mi>=0)return playMovie(mi)}if(r.type==="Series"&&typeof openSeriesInfo==="function"){window.currentSeries=window.seriesStreams&&window.seriesStreams.length?window.seriesStreams:window.currentSeries;var si=window.currentSeries.indexOf(r.item);if(si>=0)return openSeriesInfo(si)}}
setTimeout(function(){try{renderPremiumHome()}catch(e){console.log("premium home",e)}},900);
document.addEventListener("keydown",function(e){var k=e.key||e.code||"";if(k==="Search"||e.keyCode===65376){try{openUniversalSearch();e.preventDefault()}catch(x){}}},true);


/* ===== V6.4 Mobile Click / Touch Fix ===== */
function poomaniRunHomeAction(action){
  if(!action)return false;
  try{
    if(action==="live" || action==="livetv" || action==="liveTv" || action==="openLive"){
      if(typeof openLive==="function")return openLive(),true;
      if(typeof loadLive==="function")return loadLive(),true;
      if(typeof showLive==="function")return showLive(),true;
      if(typeof showPage==="function"){showPage("livePage"); if(typeof loadLiveCategories==="function")loadLiveCategories(); return true;}
    }
    if(action==="movies" || action==="movie" || action==="openMovies"){
      if(typeof openMovies==="function")return openMovies(),true;
      if(typeof loadMovies==="function")return loadMovies(),true;
      if(typeof showMovies==="function")return showMovies(),true;
      if(typeof showPage==="function"){showPage("moviesPage"); if(typeof loadMovieCategories==="function")loadMovieCategories(); return true;}
    }
    if(action==="series" || action==="openSeries"){
      if(typeof openSeries==="function")return openSeries(),true;
      if(typeof loadSeries==="function")return loadSeries(),true;
      if(typeof showSeries==="function")return showSeries(),true;
      if(typeof showPage==="function"){showPage("seriesPage"); if(typeof loadSeriesCategories==="function")loadSeriesCategories(); return true;}
    }
    if(action==="catchup" || action==="catchupTv" || action==="openCatchup"){
      if(typeof openCatchup==="function")return openCatchup(),true;
      if(typeof loadCatchup==="function")return loadCatchup(),true;
      if(typeof showCatchup==="function")return showCatchup(),true;
      if(typeof showPage==="function"){showPage("catchupPage"); if(typeof loadCatchupCategories==="function")loadCatchupCategories(); return true;}
    }
    if(action==="openUniversalSearch")return openUniversalSearch(),true;
    if(action==="closeUniversalSearch")return closeUniversalSearch(),true;
  }catch(e){
    try{console.log("poomaniRunHomeAction error",action,e)}catch(x){}
  }
  return false;
}

function poomaniFindActionElement(el){
  while(el && el!==document.body){
    if(el.dataset && (el.dataset.action || el.dataset.movieIndex || el.dataset.searchIndex || el.dataset.continueIndex))return el;
    el=el.parentNode;
  }
  return null;
}

function poomaniMobileActivate(el){
  el=poomaniFindActionElement(el);
  if(!el)return false;
  if(el.dataset.searchIndex && typeof openSearchResult==="function"){
    openSearchResult(parseInt(el.dataset.searchIndex,10)); return true;
  }
  if(el.dataset.movieIndex && typeof playMovie==="function"){
    var idx=parseInt(el.dataset.movieIndex,10);
    try{
      if(window.vodStreams && window.vodStreams.length)window.currentMovies=window.vodStreams;
      playMovie(idx); return true;
    }catch(e){}
  }
  if(el.dataset.continueIndex){
    try{
      var arr=JSON.parse(localStorage.getItem("poomani_continue_v1")||"[]");
      var item=arr[parseInt(el.dataset.continueIndex,10)];
      if(item && item.url && typeof playUrl==="function"){playUrl(item.url,item.title||"Continue Watching");return true;}
    }catch(e){}
  }
  var action=el.dataset.action;
  if(poomaniRunHomeAction(action))return true;
  if(typeof handleAction==="function"){
    try{handleAction(el); return true;}catch(e){try{console.log("handleAction failed",e)}catch(x){}}
  }
  return false;
}

document.addEventListener("click",function(e){
  var el=poomaniFindActionElement(e.target);
  if(el){
    e.preventDefault();
    e.stopPropagation();
    poomaniMobileActivate(el);
  }
},true);

document.addEventListener("touchend",function(e){
  var el=poomaniFindActionElement(e.target);
  if(el){
    e.preventDefault();
    e.stopPropagation();
    poomaniMobileActivate(el);
  }
},true);

/* Make premium cards clickable on mobile browsers */
setTimeout(function(){
  try{
    var nodes=document.querySelectorAll(".premium-card,.latest-poster,.continue-card,.search-result-card");
    for(var i=0;i<nodes.length;i++){
      nodes[i].style.cursor="pointer";
      nodes[i].setAttribute("tabindex","0");
    }
  }catch(e){}
},1200);

/* V6.5 keep uploaded background image */
setTimeout(function(){
  try{
    document.documentElement.style.setProperty('--poomani-bg-image','url("../images/app_bg.jpg")');
    var root=document.getElementById("homePage")||document.getElementById("mainPage")||document.querySelector(".premium-home");
    if(root)root.classList.add("premium-home");
  }catch(e){}
},300);
